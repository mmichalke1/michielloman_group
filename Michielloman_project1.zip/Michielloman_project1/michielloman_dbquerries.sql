﻿/*Michielloman Group - HBA Database
Matthew Michalke, Tommy Munichiello, Charlie Ackerman*/

USE HBA_Database;

/* Querry 1 - Select * From all tables - we want to see every column from every table*/

SELECT *
FROM Agent;

SELECT *
FROM Customer;

SELECT *
FROM Hotel;

SELECT *
FROM Trips;

/* Query 2 - Aggregate Function - 
	we want to see the total amounts sold by each Agent in descending order*/

SELECT a.AgentName,
	SUM(TotalPrice) as 'Total Sold'
FROM Agent as a JOIN Trips as t on a.AgentID=t.AgentID
GROUP BY a.AgentName
ORDER BY SUM(TotalPrice) DESC;

/* Query 3 - Selects records from 2 or more tables using inner join - 
	We want to see which customers took a trip and where we are missing info*/
SELECT c.FirstName, 
	c.LastName,
	t.TripID,
	t.TotalNights,
	t.TotalPrice
FROM Trips as t INNER JOIN Customer as c ON t.CustomerID=c.CustomerID

/* Query 4 - uses left outer join - 
	We want to see what hotels had visits and where we are missing data*/
Select h.HotelName,
	HotelLocation,
	t.TotalNights,
	t.TotalPrice
From Hotel as H Left Outer Join Trips as t ON h.HotelID=t.HotelID


/* Query 5 - Subquery - 
	We want to see which Agent(s) have Total Sales that are less than average so they can improve (or be fired)*/

Select a.AgentName,
	SUM(TotalPrice) as 'Total Sold'
FROM Agent as a JOIN Trips as t on a.AgentID=t.AgentID
GROUP BY a.AgentName
HAVING SUM(TotalPrice)<(Select AVG(TotalPrice) 
					FROM Agent as a JOIN Trips as t on a.AgentID=t.AgentID
					)
ORDER BY SUM(TotalPrice) DESC;