﻿/*Michielloman Group - HBA Database
Matthew Michalke, Tommy Munichiello, Charlie Ackerman*/

--Create Database
CREATE DATABASE HBA_Database

USE HBA_Database
--Create Tables
DROP TABLE IF EXISTS Customer;
CREATE TABLE Customer(
	CustomerID integer NOT NULL PRIMARY KEY,
	FirstName varchar(255),
	LastName varchar(255),
	Email varchar(255),
	Hometown varchar(255)
);

CREATE TABLE Agent (
	AgentID int NOT NULL PRIMARY KEY,
	AgentName varchar(255),
	OfficeLocation varchar(255)
);

CREATE TABLE Hotel (
	HotelID int NOT NULL PRIMARY KEY,
	HotelName varchar(255),
	HotelLocation varchar(255),
	TotalRooms int
);

CREATE TABLE Trips (
	TripID int NOT NULL PRIMARY KEY,
	CustomerID int FOREIGN KEY REFERENCES Customer(CustomerID),
	HotelID int FOREIGN KEY REFERENCES Hotel(HotelID),
	AgentID int FOREIGN KEY REFERENCES Agent(AgentID),
	TotalNights int,
	TotalPrice int
);

INSERT INTO Customer(CustomerID, FirstName, LastName, Email, Hometown)
VALUES (100001,'Rick','James','RickJames58@gmail.com','Boston, MA'),
(100002,'Bob','Dylan','BobDylan53@gmail.com','Cleveland, OH'),
(100003,'Wayne','Gretzky','WayneGretzky86@gmail.com','Worchester, MA'),
(100004,'Wayne','Simmonds','WayneSimmonds56@gmail.com','Columbus, OH'),
(100005,'Brad','Pitt','BradPitt76@gmail.com','Newton, MA'),
(100006,'Elvis','Presley','ElvisPresley56@gmail.com','Cambridge, MA'),
(100007,'Jimi','Hendrix','JimiHendrix57@gmail.com','Springfield, MA'),
(100008,'Bruce','Banner','BruceBanner46@gmail.com','Rochester, NY'),
(100009,'Jim','Brody','JimBrody61@gmail.com','Foxboro, MA'),
(100010,'Lebron','James','LebronJames26@gmail.com','Akron, OH'),
(100011,'Jim','Bean',NULL,NULL)
;

INSERT INTO Agent(AgentID, AgentName, OfficeLocation)
VAlUES (1001,'Tom Clansy','Boston, MA'),
(1002,'James Bond','Cleveland, OH'),
(1003,'Jack Reacher','Worchester, MA'),
(1004,'Nick Fury','Columbus, OH'),
(1005,'Sherlock Holmes','Rochester, NY'),
(1006, 'McBeth', NULL)
;

INSERT INTO Hotel(HotelID, HotelName, HotelLocation, TotalRooms)
VALUES (101,'Mariott','Boston, MA',200),
(102,'Courtyard','Cleveland, MA',150),
(103,'Hilton','New York, NY',300),
(104,'Motel 8' ,'Worchester, MA',100),
(105, 'Hampton Inn', 'Columbus, OH', NULL)
;

INSERT INTO Trips(TripID, CustomerID, HotelID, AgentID, TotalNights, TotalPrice)
VALUES (20000001,100001,102,1001,3,450),
(20000002,100003,102,1003,2,178),
(20000003,100004,102,1002,5,490),
(20000004,100003,105,1003,1,360),
(20000005,100008,101,1005,3,120),
(20000006,100009,101,1001,2,398),
(20000007,100010,101,1002,1,159),
(20000008,100002,103,1002,6,456),
(20000009,100001,103,1001,3,507),
(20000010,100003,103,1001,NULL,NULL)
;